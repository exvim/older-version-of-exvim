README_lang.txt for version 7.1 of Vim: Vi IMproved.

This file contains files for non-English languages:
- Translated messages.
- Translated menus.
