README_bindos.txt for version 7.0 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim70rt.zip).


There are several binary distributions of Vim for the PC.  You would normally
pick only one of them, but it's also possible to install several.
These ones are available (the version number may differ):
	vim70d16.zip	16 bit DOS version
	vim70d32.zip	32 bit DOS version
	vim70w32.zip	Windows 95/98/NT/etc. console version
	gvim70.zip	Windows 95/98/NT/etc. GUI version
	gvim70ole.zip	Windows 95/98/NT/etc. GUI version with OLE
	gvim70_s.zip	Windows 3.1 GUI version

You MUST also get the runtime archive (vim70rt.zip).
The sources are also available (vim70src.zip).
