The plugin directory is for standard Vim plugin scripts.

All files here ending in .vim will be sourced by Vim when it starts up.

Standard plugins:
gzip.vim	edit compressed files
netrw.vim	edit files over a network and browse (remote) directories
rrhelper.vim	used for --remote-wait editing
tar.vim		edit (compressed) tar files
tohtml.vim	convert a file with syntax highlighting to HTML
vimball.vim	create and unpack .vba files

Note: the explorer.vim plugin is no longer here, the netrw.vim plugin has
taken over browsing directories (also over ftp).

